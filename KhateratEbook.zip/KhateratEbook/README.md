# KhateratEbook
A simple ebook application for Garcia Marquez's Memories of My Melancholy Whores. This is a Persian translation by Mehdi Haghgoo

اپلیکیشن اندرویدی کتاب 

خاطرات روسپی های غمگین من

ترجمه مهدی حقگو 

Developed with Android Studio 2.3.1 
